package com.benagoub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj12ProdottiSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
